select = "select password from user where\
username=%s;"

print(select)